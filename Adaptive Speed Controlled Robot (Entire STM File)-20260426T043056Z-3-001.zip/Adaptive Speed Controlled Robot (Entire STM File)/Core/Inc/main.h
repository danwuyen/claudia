/* USER CODE BEGIN Header */  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes */
#include "stm32l4xx_hal.h"

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

void Error_Handler(void);

/* Private defines */
#define SENSOR_LEFT_Pin GPIO_PIN_0
#define SENSOR_LEFT_GPIO_Port GPIOC
#define SENSOR_CENTER_Pin GPIO_PIN_1
#define SENSOR_CENTER_GPIO_Port GPIOC
#define SENSOR_RIGHT_Pin GPIO_PIN_3
#define SENSOR_RIGHT_GPIO_Port GPIOC
#define USART_TX_Pin GPIO_PIN_2
#define USART_TX_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define WTF_IS_THIS__Pin GPIO_PIN_5
#define WTF_IS_THIS__GPIO_Port GPIOA
#define TRIG_Pin GPIO_PIN_6
#define TRIG_GPIO_Port GPIOA
#define IN1_Pin GPIO_PIN_0
#define IN1_GPIO_Port GPIOB
#define IN2_Pin GPIO_PIN_1
#define IN2_GPIO_Port GPIOB
#define IN3_Pin GPIO_PIN_2
#define IN3_GPIO_Port GPIOB
#define IN4_Pin GPIO_PIN_10
#define IN4_GPIO_Port GPIOB
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB
#define ECHO_Pin GPIO_PIN_9
#define ECHO_GPIO_Port GPIOB


#ifdef __cplusplus
}
#endif

#endif /* MAIN_H */
